import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { connectToDatabase } from "@/lib/mongodb";
import Subscription from "@/models/Subscription";
import { cancelTrial } from "@/actions/subscription";

export const dynamic = "force-dynamic";
const money = (cents: number) => (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export default async function SubscriptionPage({ searchParams }: { searchParams: Promise<{ cancelado?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/entrar");
  if (user.role !== "owner") redirect("/cliente");
  await connectToDatabase();
  const subscription = await Subscription.findOne({ ownerId: user.id }).lean();
  const params = await searchParams;
  const remaining = subscription?.trialEndsAt ? Math.max(0, Math.ceil((new Date(subscription.trialEndsAt).getTime() - Date.now()) / 86400000)) : 0;
  const trialDate = subscription?.trialEndsAt ? new Date(subscription.trialEndsAt).toLocaleDateString("pt-BR") : "—";
  return <main className="min-h-screen bg-slate-950 px-4 py-10 text-white sm:px-8"><div className="mx-auto max-w-3xl"><Link href="/dashboard" className="text-sm text-slate-400 hover:text-white">← Voltar ao painel</Link><h1 className="mt-6 text-3xl font-bold">Minha assinatura</h1><p className="mt-2 text-slate-400">Gerencie seu período de teste e sua contratação.</p>
    {params.cancelado && <p className="mt-5 rounded-xl bg-emerald-500/10 p-4 text-sm text-emerald-200">Seu teste foi cancelado. Nenhuma cobrança será realizada.</p>}
    <section className="mt-8 rounded-2xl border border-white/10 bg-white/[0.04] p-6"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm text-slate-400">Plano completo</p><p className="mt-1 text-2xl font-bold">AgendaFlow</p></div><span className="rounded-full bg-indigo-400/15 px-3 py-1 text-xs font-semibold text-indigo-200">{subscription?.status === "trialing" ? "Teste grátis" : subscription?.status ?? "Sem assinatura"}</span></div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2"><div className="rounded-xl bg-slate-900 p-4"><p className="text-xs text-slate-500">Período de teste termina em</p><p className="mt-1 text-lg font-semibold">{trialDate}</p><p className="mt-1 text-sm text-slate-400">{remaining} dia(s) restante(s)</p></div><div className="rounded-xl bg-slate-900 p-4"><p className="text-xs text-slate-500">Preço após o teste</p><p className="mt-1 text-lg font-semibold">R$ 39,90/mês</p><p className="mt-1 text-sm text-slate-400">ou R$ 399,00/ano</p></div></div>
      <div className="mt-6 rounded-xl border border-white/10 p-4"><p className="font-semibold">Empreendimentos</p><p className="mt-1 text-sm text-slate-400">1 incluído. Cada adicional: {money(1990)}/mês ou {money(19900)}/ano.</p></div>
      {subscription?.status === "trialing" && <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center"><p className="flex-1 text-sm leading-6 text-slate-400">Ao final do teste, nenhuma cobrança será feita automaticamente. Você precisará escolher um plano e concluir o pagamento.</p><form action={cancelTrial}><button className="rounded-xl border border-rose-400/30 px-4 py-3 text-sm font-semibold text-rose-200 hover:bg-rose-400/10">Cancelar teste</button></form></div>}
      {subscription?.status === "trialing" && <div className="mt-5 rounded-xl bg-amber-400/10 p-4 text-sm text-amber-100">A contratação pelo Mercado Pago será habilitada quando as credenciais e o webhook estiverem configurados. Não realize pagamentos por links externos enviados por terceiros.</div>}
    </section><p className="mt-6 text-xs leading-5 text-slate-500">O cancelamento do teste interrompe o acesso ao plano de avaliação. Seus dados não são apagados automaticamente; solicitações de exclusão podem ser feitas pelo canal de suporte.</p></div></main>;
}
