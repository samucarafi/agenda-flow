"use server";

import { randomBytes } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import mongoose from "mongoose";
import { z } from "zod";
import RestaurantTable from "@/models/RestaurantTable";
import WaitlistEntry from "@/models/WaitlistEntry";
import MenuCategory from "@/models/MenuCategory";
import MenuItem from "@/models/MenuItem";
import TableReservation from "@/models/TableReservation";
import BookingDayLock from "@/models/BookingDayLock";
import { getCurrentUser } from "@/lib/auth";
import { connectToDatabase } from "@/lib/mongodb";
import Business, { BUSINESS_CATEGORIES } from "@/models/Business";
import Subscription from "@/models/Subscription";
import { hasUnlimitedOwnerAccess } from "@/lib/subscription";
import BusinessMember from "@/models/BusinessMember";
import Service from "@/models/Service";
import Appointment from "@/models/Appointment";
import { Client } from "@/models/Client";

const createBusinessSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "O nome deve ter pelo menos 2 caracteres.")
    .max(100, "O nome deve ter no máximo 100 caracteres."),

  category: z.enum(BUSINESS_CATEGORIES),

  description: z
    .string()
    .trim()
    .max(1000, "A descrição é muito longa.")
    .optional()
    .or(z.literal("")),
});

export type BusinessActionState = {
  success: boolean;
  error?: string;
  business?: {
    id: string;
    name: string;
    slug: string;
    category: string;
    status: string;
  };
};

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60)
    .replace(/-+$/g, "");
}

async function generateUniqueSlug(name: string) {
  const base = slugify(name) || "negocio";

  for (let attempt = 0; attempt < 5; attempt++) {
    const suffix = randomBytes(3).toString("hex");
    const slug = `${base}-${suffix}`;

    const exists = await Business.exists({ slug });

    if (!exists) {
      return slug;
    }
  }

  throw new Error("Não foi possível gerar um endereço para o negócio.");
}

export async function deleteBusiness(formData: FormData) {
  const user = await getCurrentUser();

  if (!user) redirect("/entrar");
  if (user.role !== "owner") redirect("/cliente");

  const businessId = String(formData.get("businessId") || "");

  if (!mongoose.isValidObjectId(businessId)) {
    redirect("/dashboard/negocios");
  }

  await connectToDatabase();

  const business = await Business.findOne({
    _id: businessId,
    ownerId: user.id,
  }).select("_id slug gallery");

  if (!business) {
    redirect("/dashboard/negocios");
  }

  // Bloqueia novas reservas antes de remover os dados relacionados.
  business.set("status", "suspended");
  business.set("bookingSettings.enabled", false);
  await business.save();

  try {
    const menuImages = await MenuItem.find({ businessId: business._id })
      .select("imagePublicId")
      .lean();
    const cloudinaryPublicIds = [
      ...(business.gallery ?? []).map((image) => image.publicId),
      ...menuImages.map((image) => image.imagePublicId),
    ].filter((publicId): publicId is string => Boolean(publicId));

    // Remove primeiro os dados dependentes para evitar referências órfãs.
    await Appointment.deleteMany({ businessId: business._id });
    await WaitlistEntry.deleteMany({ businessId: business._id });
    await TableReservation.deleteMany({ businessId: business._id });
    await BookingDayLock.deleteMany({ businessId: business._id });
    await RestaurantTable.deleteMany({ businessId: business._id });
    await MenuItem.deleteMany({ businessId: business._id });
    await MenuCategory.deleteMany({ businessId: business._id });
    await Client.deleteMany({ businessId: business._id });
    await Service.deleteMany({ businessId: business._id });
    await BusinessMember.deleteMany({ businessId: business._id });

    await Business.deleteOne({
      _id: business._id,
      ownerId: user.id,
    });

    // A remoção de arquivos é best-effort: uma indisponibilidade do Cloudinary
    // não deve desfazer nem bloquear a exclusão dos dados do negócio.
    if (cloudinaryPublicIds.length > 0) {
      try {
        const { cloudinary } = await import("@/lib/cloudinary");
        const results = await Promise.allSettled(
          cloudinaryPublicIds.map((publicId) =>
            cloudinary.uploader.destroy(publicId, {
              resource_type: "image",
              invalidate: true,
            }),
          ),
        );
        const failures = results.filter((result) => result.status === "rejected");
        if (failures.length > 0) {
          console.error(`deleteBusiness: ${failures.length} arquivo(s) não foram removidos do Cloudinary.`);
        }
      } catch (cloudinaryError) {
        console.error("deleteBusiness: não foi possível limpar arquivos do Cloudinary", cloudinaryError);
      }
    }

    revalidatePath("/dashboard/negocios");
    revalidatePath(`/b/${business.slug}`);
    revalidatePath(`/b/${business.slug}/agendar`);
  } catch (error) {
    console.error("deleteBusiness:", error);

    // Se a exclusão falhar, o negócio permanece suspenso,
    // evitando novas reservas até que o problema seja resolvido.
    redirect(`/dashboard/negocios?error=delete`);
  }

  redirect("/dashboard/negocios?success=deleted");
}

export async function createBusiness(
  _previousState: BusinessActionState,
  formData: FormData,
): Promise<BusinessActionState> {
  const user = await getCurrentUser();

  if (!user) {
    return {
      success: false,
      error: "Sua sessão expirou. Entre novamente.",
    };
  }

  if (user.role !== "owner") {
    return {
      success: false,
      error: "Você não tem permissão para criar negócios.",
    };
  }

  const parsed = createBusinessSchema.safeParse({
    name: formData.get("name"),
    category: formData.get("category"),
    description: formData.get("description") ?? "",
  });

  if (!parsed.success) {
    return {
      success: false,
      error: parsed.error.issues[0]?.message ?? "Dados inválidos.",
    };
  }

  try {
    await connectToDatabase();

    const unlimited = await hasUnlimitedOwnerAccess(user.id, user.email);
    if (!unlimited) {
      const subscription = await Subscription.findOne({ ownerId: user.id });
      const currentCount = await Business.countDocuments({ ownerId: user.id });
      if (!subscription) {
        return { success: false, error: "Sua assinatura não foi encontrada. Entre em contato com o suporte." };
      }
      if (subscription.status === "trialing" && subscription.trialEndsAt.getTime() <= Date.now()) {
        subscription.status = "expired";
        await subscription.save();
      }
      const isEntitled = subscription.status === "trialing" || subscription.status === "active";
      if (!isEntitled) {
        return { success: false, error: "Seu período de teste terminou. Acesse Minha assinatura para contratar um plano." };
      }
      const allowedCount = 1 + (subscription.status === "active" ? subscription.additionalBusinesses : 0);
      if (currentCount >= allowedCount) {
        return { success: false, error: "Seu plano inclui 1 empreendimento. Contrate um adicional em Minha assinatura para cadastrar outro." };
      }
    }

    const slug = await generateUniqueSlug(parsed.data.name);

    const business = await Business.create({
      ownerId: user.id,
      name: parsed.data.name,
      slug,
      category: parsed.data.category,
      description: parsed.data.description ?? "",
      status: "draft",
      timezone: "America/Sao_Paulo",
      theme: {
        template: parsed.data.category,
      },
      bookingSettings: {
        enabled: false,
        confirmationMode: "manual",
        minAdvanceMinutes: 60,
        maxDaysInAdvance: 60,
      },
      availability: {
        workingDays: [1, 2, 3, 4, 5, 6],
        openingTime: "09:00",
        closingTime: "18:00",
        slotIntervalMinutes: 30,
      },
    });

    // O ownerId é a referência principal de propriedade.
    // A associação também permite evoluir para equipes.
    try {
      await BusinessMember.create({
        businessId: business._id,
        userId: user.id,
        role: "owner",
        active: true,
      });
    } catch (membershipError) {
      // Uma falha de associação não deve deixar o dono
      // sem acesso ao negócio que acabou de criar.
      console.error("createBusiness membership:", membershipError);
    }

    revalidatePath("/dashboard/negocios");
    redirect(`/dashboard/negocios/${business._id.toString()}/configuracoes`);
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "digest" in error &&
      String(error.digest).startsWith("NEXT_REDIRECT")
    ) {
      throw error;
    }
    console.error("createBusiness:", error);

    return {
      success: false,
      error: "Não foi possível criar o negócio. Tente novamente.",
    };
  }
}

export async function saveBusinessSettings(formData: FormData) {
  const user = await getCurrentUser();

  if (!user) redirect("/entrar");
  if (user.role !== "owner") redirect("/cliente");

  const businessId = String(formData.get("businessId") || "");

  if (!mongoose.isValidObjectId(businessId)) {
    redirect("/dashboard/negocios");
  }

  const requestedIntent = String(formData.get("intent") ?? "save");
  const intent =
    requestedIntent === "publish" || requestedIntent === "save-and-tables"
      ? requestedIntent
      : "save";

  const workingDays = formData
    .getAll("workingDays")
    .map((value) => Number(value));

  const schema = z.object({
    openingTime: z
      .string()
      .regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/, "Horário de abertura inválido."),
    closingTime: z
      .string()
      .regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/, "Horário de fechamento inválido."),

    slotIntervalMinutes: z.coerce
      .number()
      .int()
      .refine((value) => [15, 30, 60].includes(value)),

    minAdvanceMinutes: z.coerce.number().int().min(0).max(10080),
    maxDaysInAdvance: z.coerce.number().int().min(1).max(365),
    confirmationMode: z.enum(["manual", "automatic"]),

    postalCode: z
      .string()
      .trim()
      .regex(/^\d{5}-?\d{3}$/, "Informe um CEP válido com 8 números."),

    street: z.string().trim().min(2, "Informe o nome da rua.").max(150),
    number: z.string().trim().min(1, "Informe o número do endereço.").max(20),
    complement: z.string().trim().max(100).default(""),
    district: z.string().trim().min(2, "Informe o bairro.").max(100),
    city: z.string().trim().min(2, "Informe a cidade.").max(100),

    state: z
      .string()
      .trim()
      .toUpperCase()
      .pipe(
        z.string().regex(/^[A-Z]{2}$/, "Informe a sigla do estado. Ex.: RJ."),
      ),

    reference: z.string().trim().max(150).default(""),

    primaryColor: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .default("#0F172A"),

    accentColor: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .default("#06B6D4"),

    themeTemplate: z.enum(["default", "minimal", "bold"]).default("default"),
  });

  const parsed = schema.safeParse({
    openingTime: String(formData.get("openingTime") ?? ""),
    closingTime: String(formData.get("closingTime") ?? ""),
    slotIntervalMinutes: formData.get("slotIntervalMinutes") ?? "30",
    minAdvanceMinutes: formData.get("minAdvanceMinutes") ?? "60",
    maxDaysInAdvance: formData.get("maxDaysInAdvance") ?? "60",
    confirmationMode: formData.get("confirmationMode") ?? "manual",

    postalCode: String(
      formData.get("addressZipCode") ?? formData.get("postalCode") ?? "",
    ),
    street: String(
      formData.get("addressStreet") ?? formData.get("street") ?? "",
    ),
    number: String(
      formData.get("addressNumber") ?? formData.get("number") ?? "",
    ),
    complement: String(
      formData.get("addressComplement") ?? formData.get("complement") ?? "",
    ),
    district: String(
      formData.get("addressNeighborhood") ?? formData.get("district") ?? "",
    ),
    city: String(formData.get("addressCity") ?? formData.get("city") ?? ""),
    state: String(formData.get("addressState") ?? formData.get("state") ?? ""),
    reference: String(
      formData.get("addressReference") ?? formData.get("reference") ?? "",
    ),

    primaryColor: String(formData.get("primaryColor") ?? "#0F172A"),
    accentColor: String(formData.get("accentColor") ?? "#06B6D4"),
    themeTemplate: String(formData.get("themeTemplate") ?? "default"),
  });

  const settingsUrl = `/dashboard/negocios/${businessId}/configuracoes`;

  if (!parsed.success) {
    console.error("saveBusinessSettings validation:", parsed.error.flatten());

    redirect(`${settingsUrl}?error=invalid`);
  }

  if (
    workingDays.length === 0 ||
    workingDays.some((day) => !Number.isInteger(day) || day < 0 || day > 6) ||
    new Set(workingDays).size !== workingDays.length
  ) {
    redirect(`${settingsUrl}?error=days`);
  }

  const {
    openingTime,
    closingTime,
    slotIntervalMinutes,
    minAdvanceMinutes,
    maxDaysInAdvance,
    confirmationMode,
    postalCode,
    street,
    number,
    complement,
    district,
    city,
    state,
    primaryColor,
    accentColor,
    themeTemplate,
  } = parsed.data;

  if (openingTime >= closingTime) {
    redirect(`${settingsUrl}?error=hours`);
  }

  try {
    await connectToDatabase();

    // Garante que somente o proprietário possa alterar este negócio.
    const business = await Business.findOne({
      _id: businessId,
      ownerId: user.id,
    });

    if (!business) {
      redirect("/dashboard/negocios");
    }

    if (intent === "publish") {
      if (business.category === "restaurant") {
        const activeTables = await RestaurantTable.countDocuments({
          businessId: business._id,
          active: true,
        });

        if (activeTables === 0) {
          redirect(`${settingsUrl}?error=tables`);
        }
      } else {
        const activeServices = await Service.countDocuments({
          businessId: business._id,
          active: true,
        });

        if (activeServices === 0) {
          redirect(`${settingsUrl}?error=services`);
        }
      }

      business.set("status", "active");
      business.set("bookingSettings.enabled", true);
    }

    // Horários de atendimento.
    business.set("availability", {
      workingDays,
      openingTime,
      closingTime,
      slotIntervalMinutes,
    });

    // Regras de agendamento.
    business.set("bookingSettings.minAdvanceMinutes", minAdvanceMinutes);
    business.set("bookingSettings.maxDaysInAdvance", maxDaysInAdvance);
    business.set("bookingSettings.confirmationMode", confirmationMode);

    // Aparência da página pública.
    business.set("theme.template", themeTemplate);
    business.set("theme.primaryColor", primaryColor);
    business.set("theme.accentColor", accentColor);

    // Normaliza o CEP para armazenar somente números.
    const normalizedPostalCode = postalCode.replace(/\D/g, "");

    if (normalizedPostalCode.length !== 8) {
      redirect(`${settingsUrl}?error=address`);
    }

    // address corresponde ao objeto definido em Business.ts
    // e ao formato esperado por BusinessAddressFields.
    business.set("address", {
      zipCode: normalizedPostalCode,
      street,
      number,
      complement,
      neighborhood: district,
      city,
      state,
    });

    await business.save();

    // Atualiza as páginas que dependem das configurações.
    revalidatePath("/dashboard/negocios");
    revalidatePath(`/dashboard/negocios/${businessId}`);
    revalidatePath(settingsUrl);
    revalidatePath(`/b/${business.slug}`);
    revalidatePath(`/b/${business.slug}/agendar`);
  } catch (error) {
    const digest =
      typeof error === "object" && error !== null && "digest" in error
        ? String(error.digest)
        : "";

    // O Next.js usa redirect por meio de uma exceção interna.
    if (digest.startsWith("NEXT_REDIRECT")) {
      throw error;
    }

    console.error("saveBusinessSettings:", error);

    redirect(`${settingsUrl}?error=save`);
  }

  if (intent === "publish") {
    redirect(`/dashboard/negocios/${businessId}?success=published`);
  }

  if (intent === "save-and-tables") {
    redirect(`/dashboard/negocios/${businessId}/mesas`);
  }

  redirect(`${settingsUrl}?success=${intent}`);
}
