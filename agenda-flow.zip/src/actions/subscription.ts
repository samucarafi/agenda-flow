"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { connectToDatabase } from "@/lib/mongodb";
import Subscription from "@/models/Subscription";
export async function cancelTrial() {
 const user = await getCurrentUser(); if (!user) redirect("/entrar"); if (user.role !== "owner") redirect("/cliente");
 await connectToDatabase(); const subscription = await Subscription.findOne({ ownerId: user.id, status: "trialing" });
 if (!subscription) redirect("/dashboard/assinatura?erro=nao-encontrada");
 subscription.status = "cancelled"; subscription.cancelledAt = new Date(); await subscription.save();
 revalidatePath("/dashboard"); revalidatePath("/dashboard/assinatura"); redirect("/dashboard/assinatura?cancelado=1");
}
