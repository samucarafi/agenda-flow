import mongoose, { Schema, type Document, type Model } from "mongoose";

export type SubscriptionStatus = "trialing" | "pending_payment" | "active" | "cancelled" | "expired";
export type BillingInterval = "month" | "year";

export interface ISubscription extends Document {
  ownerId: mongoose.Types.ObjectId;
  status: SubscriptionStatus;
  trialStartedAt: Date;
  trialEndsAt: Date;
  trialUsedAt: Date;
  billingInterval?: BillingInterval;
  amountCents?: number;
  additionalBusinesses: number;
  cancelledAt?: Date;
  provider: "mercado_pago" | "none";
  providerSubscriptionId?: string;
  createdAt: Date;
  updatedAt: Date;
}

const subscriptionSchema = new Schema<ISubscription>({
  ownerId: { type: Schema.Types.ObjectId, ref: "User", required: true, unique: true, index: true },
  status: { type: String, enum: ["trialing", "pending_payment", "active", "cancelled", "expired"], required: true, default: "trialing", index: true },
  trialStartedAt: { type: Date, required: true },
  trialEndsAt: { type: Date, required: true, index: true },
  trialUsedAt: { type: Date, required: true },
  billingInterval: { type: String, enum: ["month", "year"] },
  amountCents: { type: Number, min: 0 },
  additionalBusinesses: { type: Number, min: 0, default: 0 },
  cancelledAt: { type: Date },
  provider: { type: String, enum: ["mercado_pago", "none"], default: "none", required: true },
  providerSubscriptionId: { type: String, trim: true, maxlength: 120 },
}, { timestamps: true });

const Subscription = (mongoose.models.Subscription as Model<ISubscription> | undefined) ?? mongoose.model<ISubscription>("Subscription", subscriptionSchema);
export default Subscription;
